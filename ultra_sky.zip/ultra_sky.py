bl_info = {
    "name": "Ultra Sky",
    "author": "masbaco",
    "version": (0, 1, 0),
    "blender": (2, 80, 0),
    "location": "View3D",
    "description": "Add New Scene",
    "warning": "",
    "wiki_url": "",
    "category": "Scene",
    }
 
 
 
import bpy
import os   
    
class SKY_MAINPANEL(bpy.types.Panel):
    bl_label = "Baco Sky"
    bl_idname = "NODE_PT_MAINPANEL"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Awesome Sky' 
 
    def draw(self, context):
        layout = self.layout
 
        row = layout.row()
        row.label(text= "ADD NEW SCENE", icon= 'WORLD_DATA')
        row.operator('node.sky_operator')
        
        


        
        
class GENERATE_SKY_PANEL(bpy.types.Operator):
    bl_label = "Do MAGIC"
    bl_idname = "node.sky_operator"
    
    def execute(self, context):
        
        filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ultra_sky.blend")
    
    
    
        with bpy.data.libraries.load(filepath) as (data_from, data_to):
            files = []
            for obj in data_from.scenes:
                files.append({'name' : obj})
            bpy.ops.wm.append(directory=filepath+'\\Scene\\', files=files)   
            
            
            
            
            
            
             
        
        
        


        
        
        

        return {'FINISHED'}                 
        
        
            
    
   
    
    
def register():
    bpy.utils.register_class(SKY_MAINPANEL)
    bpy.utils.register_class(GENERATE_SKY_PANEL)
    
    
    
    
 
 
def unregister():
    bpy.utils.unregister_class(SKY_MAINPANEL)
    bpy.utils.unregister_class(GENERATE_SKY_PANEL)
    
 
 
if __name__ == "__main__":
    register()